GET_TOKEN="https://azure.microsoft.com/zh-cn/products/cognitive-services/speech-to-text/"

def voice_list_url() -> str:
    return f'https://eastus.api.speech.microsoft.com/cognitiveservices/voices/list'
